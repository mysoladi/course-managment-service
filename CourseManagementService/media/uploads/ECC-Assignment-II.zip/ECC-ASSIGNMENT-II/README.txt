The ipynb contains all the code for the questions asked in the assignment.
The notebook comprises of both the parts NYC Parking and NBA Shot Logs

- Open the ipynb file on 'Google colab' using the web browser.

- Create a new notebook/ or upload the existing ipynb file to the google colab and run all the cells as I have provided.

- Then import pyspark and findspark and run fs.init(), if this executes without any errors then spark is ready to use.

- Create the Spark Session, allocate the # of cores required in .master('local[#]'). (I have provided # = 5)

- Use spark to execute the required code and answer the questions.

- Remember to stop the spark session after using it completely. 






By athjoshi (athjoshi@iu.edu)